//longest common subsequence

import static java.lang.System.*;
import java.util.*;
class Lcs
{   
  String str1,str2; 
  char s1_arr[]=new char[30];
  char s2_arr[]=new char[30];
  int c[][]=new int[30][30];

	void longestCommonSubsequence()
	{
		Scanner sc=new Scanner(System.in);
		out.println("Enter String1 :-");
		str1=sc.nextLine();
		out.println("Enter String2 :-");
		str2=sc.nextLine();
		createMatrix();

    }
	void createMatrix()
	{
     s1_arr=str1.toCharArray();
     s2_arr=str2.toCharArray();
     
     for(int i=0;i<str1.length();i++) c[i][0]=0;
     for(int j=0;j<str2.length();j++) c[0][j]=0;	


       for(int i=1;i<=str1.length();i++)
       {
       	  for(int j=1;j<=str2.length();j++)
     	  {
             if(s1_arr[i-1]==s2_arr[j-1])
             {
              	c[i][j]=c[i-1][j-1]+1;
             }
             else
             {
             	if(c[i-1][j]>=c[i][j-1])
            	{
            		c[i][j]=c[i-1][j];
            	}
            	else
            	{
            		c[i][j]=c[i][j-1];
            	}
            }
     	  }
       }
       displayMatrix();
    }

    void displayMatrix()
    {
    	out.println("Require matrix C :-");
    	for(int i=0;i<=str1.length();i++)
    	{
    		for(int j=0;j<=str2.length();j++)
    		{
    			out.print(c[i][j]+" ");
    		}
    		out.println();
    	}
    	out.println();
    	Output();
    }

    void Output()
    {
      StringBuffer com=new StringBuffer("");

        for(int i=str1.length();com.length()!=c[str1.length()][str2.length()];)
        {
      	 for(int j=str2.length();com.length()!=c[str1.length()][str2.length()];)
      	 {
      	   
      	 	if(s1_arr[i-1]==s2_arr[j-1])
      	 	{
      	 		com.append(s1_arr[i-1]);
      	 		i=i-1;
      	 		j=j-1;
      	 	}
      	 	else
      	 	{
      	 		if(c[i-1][j]>=c[i][j-1])	i=i-1;
      	 		else j=j-1;      	 		
      	     }
      	  }
        } 
        
        com.reverse();

        String common=com.toString();
        out.println("longest Common Subsequence is "+common);
    }
}
class Test
{
	public static void main(String[] args) {
		Lcs l=new Lcs();
		l.longestCommonSubsequence();
	}
}