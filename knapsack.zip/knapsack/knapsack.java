import static java.lang.System.*;
import java.util.*;

class knapsack
{
	int W,N;
    int v[][]=new int[20][20];

	int vi[]=new int[20];
	int wi[]=new int[20];
	Scanner sc=new Scanner(System.in);


	void get_data()
	{
	  out.println("Enter total weight :-");
	  W=sc.nextInt();

	  out.println("Enter total number of object :-");
	  N=sc.nextInt();
     
      out.println("Enter profit for each object :-");
      for(int i=0;i<N;i++)
      {
      	out.print("   V"+(i+1)+"=");
      	vi[i]=sc.nextInt();
      	
      	out.println();
      }
      out.println("Enter Weight for each object :-");
      for(int i=0;i<N;i++)
      {
      	out.print("   W"+(i+1)+"=");
      	wi[i]=sc.nextInt();
      	
      	out.println();
      }
     }
     void dynamic_sol()
     {
       /*first we make first coloun and row zero of profit table*/	
       for(int i=0;i<=N;i++)
        	v[i][0]=0;
       for(int j=0;j<=W;j++)
        	v[0][j]=0;
  
       /*fill profit table by using formula*/
       for(int i=1;i<=N;i++)
       {
        	for(int j=1;j<=W;j++)
       	    {
              if(j<wi[i-1]) v[i][j]=v[i-1][j];
              else	v[i][j]=v[i-1][j-wi[i-1]]+vi[i-1];
            }
       }
       output();
      }

      void output()
      {
      	out.println("Profit table matrix v:-");
      	for(int i=0;i<=N;i++)
        {
        	for(int j=0;j<=W;j++)
       	    {
       	    	out.print(v[i][j]+"  ");
       	    }out.println();
       	}
       	out.println();
       	
         /*for find becuase of which object we get max profit*/
        int x[]=new int[N];
       	int max_profit=v[N][W];
       	int remain_profit=max_profit;
        int i=N,j=W;

       	while(remain_profit!=0)
        {     
            if(v[i][j]!=v[i-1][j])
            {
            	x[i-1]=1;
            	remain_profit-=vi[i-1];
            	int k;
                for(k=W;v[i-1][k]!=remain_profit;k--);
                j=k;	
            }
            else
            {
            	x[i-1]=0;
            }
            i--;
         }
          
         /*prinr final result*/ 
         out.print("    that means maximum profit is "+v[N][W]+" and because of object ");
         for(int k=0;k<N;k++) 
         {
         	if(x[k]==1)	out.print((k+1)+" ");
         }
         out.print(".");
      }
      
}
class Test
{
	public static void main(String[] args) {
		knapsack k=new knapsack();
		k.get_data();
		k.dynamic_sol();
	}
}