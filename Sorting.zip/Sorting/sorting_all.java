import java.util.*;
class sort
{ 
  int n=200;
  int a[]=new int[n];

  sort(){for(int i=0;i<n;i++) a[i]=n-i;}  

  void set()
  {
      for(int i=0;i<n;i++)
        a[i]=n-i;
  }
  void set_random()
  {
    Random r=new Random();
    for(int i=0;i<n;i++)
        a[i]=r.nextInt(50);

  }
  void display_array()
  {  System.out.println("YOUR ARRAY :- ");
  	for(int i=0;i<n;i++)	
     {
     	System.out.print("  "+a[i]);
     }	
  }
  void bubble()
  {
  	for(int i=0;i<n-1;i++)
  	{
      for(int j=0;j<n-1-i;j++)
      {
      	if(a[j]>a[j+1])
      	{
      		int tmp=a[j];
      		a[j]=a[j+1];
      		a[j+1]=tmp;
      	}	
      }	
  	}
  }
  void selection()
  {
  	int min;
  	for(int i=0;i<n-1;i++)
  	{
  		min=i; 
  		for(int j=i+1;j<n;j++)
  		{ 
  			if(a[j]<a[min])
  			{
  			  min=j;
  			}	
      }
     int tmp=a[min]; 
      a[min]=a[i];
      a[i]=tmp;
  	}	
   }
  void insertion()
  { int key,j;
  	for(int i=1;i<n;i++)
  	{
      key=a[i];
      for(j=i-1;j>=0;j--)
      {
      	if(key<a[j])
      	{
  		    a[j+1]=a[j];
  		   }
  		else {break; }
      }
      a[j+1]=key;
  	}	
  }
  void quicksort()
  { quicksort q=new quicksort();
    q.quicksort(a,0,n-1);
  }
  void merge_sort()
  { mergesort m=new mergesort();
    m.merge_sort(a,0,n-1,n);
  }
  
}
class Test
{
	public static void main(String[] args) {
   sort s=new sort();
   int choice;
   Scanner sc=new Scanner(System.in);

      do
      { 
        System.out.println();
        System.out.println("1.Bubble sort");
        System.out.println("2.Selection sort");
        System.out.println("3.Insertion sort");
        System.out.println("4.Quick sort");
        System.out.println("5.Merge sort");
        System.out.println("6.Show Sorted Array");
        System.out.println("7.Set array in worst case");
        System.out.println("8.Set array with random values");
        System.out.println("9.Exit");
        System.out.println("Enter choice :- ");
        choice=sc.nextInt();
        switch(choice)
        {
          case 1:
          long a1=System.nanoTime();
          s.bubble();
          long a2=System.nanoTime();
          System.out.println("TIME FOR BUBBLE SORT IS :- "+(a2-a1)+"ns");
          break;

          case 2:
          long b1=System.nanoTime();
          s.selection();
          long b2=System.nanoTime();
          System.out.println("TIME FOR SELECTION SORT IS :- "+(b2-b1)+"ns");
          break;

          case 3:
          long c1=System.nanoTime();
          s.insertion();
          long c2=System.nanoTime();
          System.out.println("TIME FOR INSERTION SORT IS :- "+(c2-c1)+"ns");
          break;

          case 4:
          long d1=System.nanoTime();
          s.quicksort();
          long d2=System.nanoTime();
          System.out.println("TIME FOR QUICK SORT IS :- "+(d2-d1)+"ns");
          break;

          case 5:
          long e1=System.nanoTime();
          s.merge_sort();
          long e2=System.nanoTime();
          System.out.println("TIME FOR MERGE SORT IS :- "+(e2-e1)+"ns");
          break;

          case 6: s.display_array(); break;

          case 7:s.set(); break;

          case 8:s.set_random(); break;

          case 9: break;

          default: System.out.println("Enter appropriate choice!");
        }
      }while(choice!=9);
     }
}
	

class quicksort
{
  void quicksort(int a[],int left,int right)
  {
    if(left<right)
    {
      int pivot=partition(a,left,right);
      quicksort(a,left,pivot-1);  
      quicksort(a,pivot+1,right);
    }
  }
  int partition(int a[],int start,int end)
  {
    int flag=0,pivot=start,left=start,right=end;
    while(flag==0)
    { 
    while(a[right]>=a[pivot]&&left!=right) right--;   
    if(pivot==right)
    {
     flag=1;  
    }
    else if((a[pivot]>a[right]))
    {
     int tmp=a[pivot];
         a[pivot]=a[right];
         a[right]=tmp;  
         pivot=right;
    } 

    if(flag==0)
    {
     while(a[left]<=a[pivot]&&left!=right) left++;
     if(pivot==left) flag=1;
     else if(a[pivot]<a[left])
     {
      int tmp=a[pivot];
         a[pivot]=a[left];
         a[left]=tmp; 
         pivot=left;
     }
    }
   }
       return pivot;
  }
}

class mergesort
{
  void merge_sort(int a[],int beg,int end,int n)
  { int tmp[]=new int[n];
    if(beg<end)
    {
    int mid=(beg+end)/2;
    merge_sort(a,beg,mid,n);
    merge_sort(a,mid+1,end,n);
    merge(a,tmp,beg,end,mid);
    }
  }
  void merge(int a[],int tmp[],int beg,int end,int mid)
  { 
    int left=beg,right=mid+1,index=beg;
        while((left<=mid)&&(right<=end))
    {
      if(a[left]<a[right])
      {
       tmp[index]=a[left];
       left++;  
      } 
      else
      {
        tmp[index]=a[right];
        right++;
      }
      index++;
    }
    while(right<=end){tmp[index]=a[right]; right++; index++;}
    while(left<=mid){tmp[index]=a[left]; left++; index++;}
    for(int k=beg;k<index;k++)
    a[k]=tmp[k];
  }
}
