class arr
{
  int n=100;
  int arr[]=new int[n];
  int bucket[][]=new int[10][n];
 arr()
 {
  for(int i=0;i<n;i++)
  {
   arr[i]=n-i;
  } 	
 }
 void radix()
 {
  int max=0,pass=0,tmp=-1,k;
  for(int i=0;i<n;i++)
  {
  	if(max<arr[i])
  		max=arr[i];
  }
  while(max!=0)
  {
  	max=max/10;
  	pass++;
  }	
  
  for(int i=0;i<pass;i++)
  {
   for(int j=0;j<n;j++)
   { 
     tmp=arr[j]/((int)Math.pow(10,i)); 	
     tmp=tmp%10;
    	
   	for(k=0;bucket[tmp][k]!='\0';k++);
     bucket[tmp][k]=arr[j];
   }
   int index=0;
   for(int p=0;p<10;p++)
   {
   	for(int q=0;bucket[p][q]!='\0';q++)
   	{
   	  arr[index]=bucket[p][q];
   	  bucket[p][q]='\0';
   	  index++;
   	}
   }
 }
}
 void show()
 {
 for(int i=0;i<n;i++)
  	System.out.print("  "+arr[i]);	
 }
}
class main
{
	public static void main(String[] args)
	{
	 //Scanner s=new Scanner(System.in);
	 arr a=new arr();
	 a.radix();
	 a.show();
	}
}